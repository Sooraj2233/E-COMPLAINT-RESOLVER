
1. Place the coding in below path 
c:\xampp\htdocs\projects\complaint\web

2. Opent  localhost/phpmyadmin
   Crete DB - complaint
   
3. Import complaint.sql 

4. For Project run the path in browser

localhost/projects/complaint/web/

Admin 
admin@gmail.com
test

User 
user@gmail.com
test

Officer
dharani@gmail.com
test 
Location: chennai
Type: street


user 2
dharani1@gmail.com
test